Locales['pl'] = {
    ["mission_row"] = "Komisariat Mission Row",
    ["phone_booth"] = "Budka telefoniczna",
    ["key_answer"] = "Nacisnij ~INPUT_PICKUP~ aby odebrać telefon",
    ["new_message"] = "~o~Nowa wiadomość",
    ["new_message_from"] = "~o~Nowa wiadomość od ~y~%s",
    ["new_message_transmitter"] = "~o~Nowa wiadomość od ~g~%s",
    ["use_fixed"] = "~g~%s telefon ~o~(%s) ~n~~INPUT_PICKUP~~w~ Użyj telefon",

    -- Social
    ["new_tweet"] = "Nowy Tweet!",

    -- Warning
    ["no_phone"] = "Nie masz ~r~phone~s~."
}