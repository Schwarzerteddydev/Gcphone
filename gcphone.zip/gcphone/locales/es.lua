Locales['es'] = {
    ["mission_row"] = "Central de policia LS",
    ["phone_booth"] = "Cabina telefónica",
    ["key_answer"] = "Presiona ~INPUT_PICKUP~ para responder el telefono",
    ["new_message"] = "~o~Nuevo Mensaje",
    ["new_message_from"] = "~o~Nuevo Mensaje de ~y~%s",
    ["new_message_transmitter"] = "~o~Nuevo mensaje de ~g~%s",
    ["use_fixed"] = "~g~Telefono fijo %s ~o~(%s) ~n~~INPUT_PICKUP~~w~ para utilizar el telefono"
}