Locales['pt'] = {
    ["mission_row"] = "Departamento da Policia",
    ["phone_booth"] = "Cabine Telefónica",
    ["key_answer"] = "Pressiona ~INPUT_PICKUP~ para atender",
    ["new_message"] = "~o~Nova mensagem",
    ["new_message_from"] = "~o~Nova mensagem de ~y~%s",
    ["new_message_transmitter"] = "~o~Nova mensagem de ~g~%s",
    ["use_fixed"] = "~g~%s's telefone ~o~(%s) ~n~~INPUT_PICKUP~~w~ Usar telefone",
    
    -- Social
    ["new_tweet"] = "Novo Tweet!",

    -- Warning
    ["no_phone"] = "Você não tem um ~r~phone~s~."
}