Locales['fr'] = {
    ["mission_row"] = "Mission Row Police",
    ["phone_booth"] = "Cabine téléphonique",
    ["key_answer"] = "Appuyez sur ~INPUT_PICKUP~ pour répondre au téléphone",
    ["new_message"] = "~o~Nouveau message",
    ["new_message_from"] = "~o~Nouveau message de ~y~%s",
    ["new_message_transmitter"] = "~o~Nouveau message de ~g~%s",
    ["use_fixed"] = "~g~Téléphone fixe %s ~o~(%s) ~n~~INPUT_PICKUP~~w~ Utiliser le téléphone",
    
    -- Social
    ["new_tweet"] = "Nouveau tweet!",
    
    -- Warning
    ["no_phone"] = "Vous n'avez pas de ~r~téléphone~s~."
}
