Locales['en'] = {
    ["mission_row"] = "Polizei",
    ["phone_booth"] = "Mechaniker",
    ["phone_ambulance"] = "Rettungsdienst",
    ["key_answer"] = "Dr�cke ~INPUT_PICKUP~ um das Telefon zu benutzen",
    ["new_message"] = "~o~Neue Nachricht",
    ["new_message_from"] = "~o~Neue Nachricht von ~y~%s",
    ["new_message_transmitter"] = "~o~Neue Nachricht von ~g~%s",
    ["use_fixed"] = "~g~%s's phone ~o~(%s) ~n~~INPUT_PICKUP~~w~ um zu nutzen"
}