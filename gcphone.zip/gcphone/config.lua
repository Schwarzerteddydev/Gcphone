Config = {}

-- Script locale (only .Lua)
Config.Locale = 'en'

Config.AutoFindFixePhones = true -- Automatically add pay phones as they are found by their models.

Config.FixePhone = {
  -- Mission Row
  ['911'] = { 
    name =  _U('mission_row'), 
    coords = { x = 441.2, y = -979.7, z = 30.58 } 
  },
  
  ['913'] = {
    name = _U('phone_booth'),
    coords = { x = 950.42, y = -979.2, z = 39.5 } 
  },
    ['912'] = {
    name = ('EMS'),
   -- coords = { x = -1852.0559, y = -336.7299, z = 49.4473 } 
	coords = { x = 340.1001, y = -582.0127, z = 28.7915 } 
  },

}

Config.KeyOpenClose = 288 -- F1
Config.KeyTakeCall  = 38  -- E

Config.UseMumbleVoIP = false -- Use Frazzle's Mumble-VoIP Resource (Recomended!) https://github.com/FrazzIe/mumble-voip
Config.UseTokoVoIP   = false

Config.ShowNumberNotification = false -- Show Number or Contact Name when you receive new SMS